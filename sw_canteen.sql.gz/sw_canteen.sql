-- MySQL dump 10.19  Distrib 10.3.38-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: skyhwdhv_canteen
-- ------------------------------------------------------
-- Server version	10.3.38-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `BILL`
--

DROP TABLE IF EXISTS `BILL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BILL` (
  `OrderID` int(11) NOT NULL AUTO_INCREMENT,
  `Order_Date` varchar(30) NOT NULL,
  `Time` varchar(30) NOT NULL,
  `CustomerID` int(11) NOT NULL,
  `Total_Amount` int(11) NOT NULL,
  PRIMARY KEY (`OrderID`),
  KEY `CustomerID` (`CustomerID`),
  CONSTRAINT `bill_ibfk_1` FOREIGN KEY (`CustomerID`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BILL`
--

LOCK TABLES `BILL` WRITE;
/*!40000 ALTER TABLE `BILL` DISABLE KEYS */;
INSERT INTO `BILL` (`OrderID`, `Order_Date`, `Time`, `CustomerID`, `Total_Amount`) VALUES (1,'2023-04-05','',18,220),(2,'2023-04-07','',17,180),(3,'2023-04-05','',17,100),(24,'2023-04-29','',2,999),(25,'2023-04-29','',2,999),(26,'2023-04-29','',2,999),(27,'2023-04-29','',2,999),(28,'2023-04-29','',2,999),(29,'2023-04-29','',2,999),(30,'2023-04-29','',18,720),(31,'2023-04-29','',18,299),(32,'2023-04-29','',18,299),(33,'2023-04-29','',18,720),(34,'2023-04-29','',18,720),(35,'2023-04-29','',18,300),(36,'2023-04-30','',18,210),(37,'2023-04-30','',18,220),(38,'2023-04-30','',18,70),(39,'2023-05-06','',18,310),(40,'2023-05-07','',18,200),(41,'2023-05-08','10:13 pm',18,120),(42,'2023-05-08','10:18 pm',18,70),(43,'2023-05-08','10:27 pm',18,260);
/*!40000 ALTER TABLE `BILL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Orders`
--

DROP TABLE IF EXISTS `Orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Orders` (
  `OrderID` int(11) NOT NULL,
  `ItemID` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `served` varchar(3) NOT NULL,
  KEY `OrderID` (`OrderID`),
  KEY `ItemID` (`ItemID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Orders`
--

LOCK TABLES `Orders` WRITE;
/*!40000 ALTER TABLE `Orders` DISABLE KEYS */;
INSERT INTO `Orders` (`OrderID`, `ItemID`, `Quantity`, `served`) VALUES (1,1,1,'no'),(1,6,1,'no'),(1,5,1,'no'),(2,8,2,'no'),(32,1,3,'yes'),(32,6,4,'yes'),(32,2,2,'yes'),(32,5,1,'yes'),(33,1,3,'yes'),(33,6,4,'yes'),(33,2,2,'yes'),(33,5,1,'yes'),(34,1,3,'yes'),(34,6,4,'yes'),(34,2,2,'yes'),(34,5,1,'yes'),(35,2,1,'yes'),(35,1,1,'yes'),(35,4,1,'yes'),(36,8,1,'yes'),(36,6,1,'yes'),(36,5,1,'yes'),(37,4,2,'yes'),(38,3,1,'no'),(39,2,3,'no'),(39,6,1,'no'),(40,1,2,'no'),(40,2,0,'no'),(41,6,1,'no'),(42,3,1,'no'),(43,2,2,'no');
/*!40000 ALTER TABLE `Orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Queue`
--

DROP TABLE IF EXISTS `Queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Queue` (
  `QueueNo` int(11) NOT NULL AUTO_INCREMENT,
  `OrderID` int(11) NOT NULL,
  `Counter` int(11) DEFAULT NULL,
  PRIMARY KEY (`QueueNo`),
  KEY `OrderID` (`OrderID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Queue`
--

LOCK TABLES `Queue` WRITE;
/*!40000 ALTER TABLE `Queue` DISABLE KEYS */;
INSERT INTO `Queue` (`QueueNo`, `OrderID`, `Counter`) VALUES (1,1,0),(2,2,0),(4,38,0),(6,39,0),(7,39,0),(8,40,0),(9,40,0);
/*!40000 ALTER TABLE `Queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_REPORT`
--

DROP TABLE IF EXISTS `SALES_REPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALES_REPORT` (
  `ItemID` int(11) NOT NULL,
  `Units_Sold` int(11) NOT NULL,
  `Total_Revenue` int(11) NOT NULL,
  UNIQUE KEY `ItemID` (`ItemID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_REPORT`
--

LOCK TABLES `SALES_REPORT` WRITE;
/*!40000 ALTER TABLE `SALES_REPORT` DISABLE KEYS */;
INSERT INTO `SALES_REPORT` (`ItemID`, `Units_Sold`, `Total_Revenue`) VALUES (1,48,4800),(2,26,2160),(3,12,840),(4,3,330),(5,41,3280),(6,93,3720),(7,10,800),(8,1,90);
/*!40000 ALTER TABLE `SALES_REPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `foodID` int(11) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `timestamp` date NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `foodID` (`foodID`),
  CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`foodID`) REFERENCES `food_list` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart`
--

LOCK TABLES `cart` WRITE;
/*!40000 ALTER TABLE `cart` DISABLE KEYS */;
INSERT INTO `cart` (`id`, `foodID`, `email`, `quantity`, `timestamp`) VALUES (1,1,'zahirulnahid@gmail.com',1,'2023-04-04'),(2,1,'zahirulnahid@gmail.com',1,'2023-04-04'),(3,1,'zahirulnahid@gmail.com',1,'2023-04-04'),(4,1,'zahirulnahid@gmail.com',1,'2023-04-04'),(5,1,'zahirulnahid@gmail.com',1,'2023-04-04'),(6,1,'zahirulnahid@gmail.com',1,'2023-04-04'),(7,1,'zahirulnahid@gmail.com',1,'2023-04-04'),(8,1,'zahirulnahid@gmail.com',1,'2023-04-04'),(9,1,'zahirulnahid@gmail.com',1,'2023-04-04'),(10,1,'zahirulnahid@gmail.com',1,'2023-04-04'),(11,1,'zahirulnahid@gmail.com',1,'2023-04-04'),(12,1,'zahirulnahid@gmail.com',1,'2023-04-04'),(13,1,'zahirulnahid@gmail.com',1,'2023-04-04'),(14,1,'zahirulnahid@gmail.com',1,'2023-04-04'),(15,1,'zahirulnahid@gmail.com',1,'2023-04-04'),(16,1,'zahirulnahid@gmail.com',1,'2023-04-04'),(44,2,'ayman@nsu.edu',1,'2023-05-08');
/*!40000 ALTER TABLE `cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `food_category`
--

DROP TABLE IF EXISTS `food_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `food_category` (
  `id` int(11) NOT NULL,
  `category` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `food_category`
--

LOCK TABLES `food_category` WRITE;
/*!40000 ALTER TABLE `food_category` DISABLE KEYS */;
INSERT INTO `food_category` (`id`, `category`) VALUES (1,'Beverage'),(2,'Fast Food'),(3,'Main Dish'),(4,'Dessert');
/*!40000 ALTER TABLE `food_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `food_list`
--

DROP TABLE IF EXISTS `food_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `food_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Item_Name` varchar(30) NOT NULL,
  `Price` int(11) NOT NULL,
  `Description` varchar(200) NOT NULL,
  `keywords` varchar(300) NOT NULL,
  `Image_url` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `food_list`
--

LOCK TABLES `food_list` WRITE;
/*!40000 ALTER TABLE `food_list` DISABLE KEYS */;
INSERT INTO `food_list` (`id`, `Item_Name`, `Price`, `Description`, `keywords`, `Image_url`) VALUES (1,'Burger',100,'A huge single or triple burger with all the fixings, cheese, lettuce, tomato, onions and special sauce or mayonnaise!','','../images/Burger.png'),(2,'Chicken Biriyani',90,'A savory chicken and rice dish that includes layers of chicken, rice, and aromatics that are steamed together.\r\n','','../images/Chicken Biriyani.png'),(3,'Chicken Curry',70,'A typical curry from the Indian subcontinent consists of chicken stewed in an onion- and tomato-based sauce\r\n','','../images/Chicken Curry.png'),(4,'Dhakaiya Kacchi',110,'Introducing the spicy and tender dhakaiya kacchi where l,ayers of meat, rice, and potatoes are infused with delicious blends of aromatic spices.\r\n','','../images/Dhakaiya Kacchi.png'),(5,'Kala Bhuna',80,'Authentic and spicy chatgaiya beef kalabhuna. Exclusive dark, flavourful and tender dish prepared with chunks of beef and traditional spices\r\n','','../images/Kala Bhuna.png'),(6,'Khichuri',40,'Authentic bangali khichuri with all the original flavors of Bengal. Made of rice and lentils (dal) with numerous variations\r\n','','../images/Khichuri.png'),(7,'Pasta',80,'This Spicy Chicken Pasta is the perfect level of spice, whilst absolutely bursting with flavour. It’s easy, creamy, hearty and delicious!.\r\n','','../images/Pasta.png'),(8,'Pizza',90,'consists of a flattened disk of bread dough topped with some combination of olive oil, oregano, tomato, olives, mozzarella\r\n','','../images/Pizza.png');
/*!40000 ALTER TABLE `food_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_id` int(11) NOT NULL,
  `receiver_id` varchar(200) NOT NULL,
  `title` text NOT NULL,
  `details` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0 = unseen, 1 = seen',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_category`
--

DROP TABLE IF EXISTS `user_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_category` (
  `id` int(11) NOT NULL,
  `category` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_category`
--

LOCK TABLES `user_category` WRITE;
/*!40000 ALTER TABLE `user_category` DISABLE KEYS */;
INSERT INTO `user_category` (`id`, `category`) VALUES (1,'Student'),(2,'Faculty'),(3,'Staff'),(4,'Admin');
/*!40000 ALTER TABLE `user_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `verified` varchar(255) NOT NULL DEFAULT 'pending',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `category`, `name`, `email`, `phone`, `password`, `verified`) VALUES (2,2,'a','a','2','a','true'),(17,1,'Md. Zahirul Islam Nahid','zahirulnahid@gmail.com','01554518620','25d55ad283aa400af464c76d713c07ad','true'),(18,1,'Ayman','ayman@nsu.edu','11111111111','1bbd886460827015e5d605ed44252251','true'),(19,4,'admin','admin@nsu.edu','11111111111','1bbd886460827015e5d605ed44252251','pending');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'skyhwdhv_canteen'
--

--
-- Dumping routines for database 'skyhwdhv_canteen'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-19 16:17:28
